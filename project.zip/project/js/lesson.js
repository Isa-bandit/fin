const phoneResult = document.querySelector('#phone_result')
const phoneButton = document.querySelector('#phone_button')
const phoneInput = document.querySelector('#phone_input')

const regExp = /^\+996 [25793]\d{2} \d{2}-\d{2}-\d{2}$/

phoneButton.onclick = () => {
    if (regExp.test(phoneInput.value.trim())) {
        phoneResult.innerHTML = 'OK'
        phoneResult.style.color = 'green'
    } else {
        phoneResult.innerHTML = 'NOT OK'
        phoneResult.style.color = 'red'
    }
}

//TAB SLIDER
const tabContentBlocks = document.querySelectorAll('.tab_content_block')
const tabs = document.querySelectorAll('.tab_content_item')
const tabsParent = document.querySelector('.tab_content_items')
let slideIndex = 0
let intervalId

const hideTabContent = () => {
    tabContentBlocks.forEach((tabCard) => {
        tabCard.style.display = "none"
    })
    tabs.forEach((tab) => {
        tab.classList.remove('tab_content_item_active')
    })
}

const showTabContent = (tabIndex = 0) => {
    hideTabContent()
    tabContentBlocks[tabIndex].style.display = "block"
    tabs[tabIndex].classList.add('tab_content_item_active')
}

const startSlider = () => {
    intervalId = setInterval(() => {
        slideIndex = (slideIndex + 1) % tabs.length
        showTabContent(slideIndex)
    }, 3000)
}


tabs.forEach((tab, tabIndex) => {
    tab.addEventListener('click', () => {
        slideIndex = tabIndex
        showTabContent(slideIndex)
    })
})

hideTabContent()
showTabContent(slideIndex)
startSlider()

//converter

const somInput = document.querySelector("#som")
const usdInput = document.querySelector("#usd")
const eurInput = document.querySelector("#eur")


const converter = (element,targetElement,secondtargetElement,current) => {
    element.oninput = () => {
        const request = new XMLHttpRequest()
        request.open('GET','../data/converter.json')
        request.setRequestHeader('COntent-type','application/json')
        request.send()

        request.onload = () => {
            const data = JSON.parse(request.response)

            switch (current) {
                case 'som':
                    targetElement.value = (element.value / data.usd).toFixed(2)
                    secondtargetElement.value = (element.value / data.eur).toFixed(2)
                    break;
                case 'usd':
                    targetElement.value = (element.value * data.usd).toFixed(2)
                    secondtargetElement.value = (targetElement.value / data.eur).toFixed(2)
                    break;
                case 'eur':
                    targetElement.value = (element.value * data.eur).toFixed(2)
                    secondtargetElement.value = (targetElement.value / data.usd).toFixed(2)                    
                default:
                    break;
            }
            
            if (element.value ==='') {
                targetElement.value = ''
                secondtargetElement.value = ''
            }

        }
    }
}

converter(somInput,usdInput,eurInput,'som')
converter(usdInput,somInput,eurInput,'usd')
converter(eurInput,somInput,usdInput,'eur')











//card switcher

const cardBlock = document.querySelector('.card')
const btnPrev = document.querySelector('#btn-prev')
const btnNext = document.querySelector('#btn-next')

let count = 1

const Fetch = async () => {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/todos/${count}`)
        const data = await response.json()

        cardBlock.innerHTML = `
            <p>${data.title}</p>
            <p style="color: ${data.completed ? 'green' : 'red'}">${data.completed}</p>
            <span>${data.id}</span>
        `
    } catch (error) {
        console.error(error)
    }
}



btnNext.onclick = () => {
    count = (count === 200) ? 1 : count + 1
Fetch()
}

btnPrev.onclick = () => {
    count = (count === 1) ? 200 : count - 1
    Fetch()
}


Fetch()

let dert = async function () {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts`)
        const data =  await response.json()
        console.log(data);
    } catch (error) {
        console.log(error);
    }
}
dert()





// weather

const searchInput = document.querySelector('.cityName')
const city = document.querySelector('.city')
const temp = document.querySelector('.temp')

const API_KEY = 'e417df62e04d3b1b111abeab19cea714'
const url = 'http://api.openweathermap.org/data/2.5/weather'

const citySearch = () => {
    searchInput.oninput = async (event) => {
        try {
        const response = await  fetch(`${url}?q=${event.target.value}&appid=${API_KEY}`)
        const  data = await response.json()
          city.innerHTML = data.name ? data.name : 'Город не найден...'
          temp.innerHTML =data.main?.temp ? Math.round(data.main.temp-273) + '&deg;C' : "..."
        } catch (error) {
            console.log(error);
        }

    }
}


citySearch()








